/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './services/**/*.{ts,tsx}',
    './utils/**/*.{ts,tsx}',
    './theme/**/*.ts',
    './*.{ts,tsx}',
  ],
  theme: {
    extend: {
      borderRadius: {
        'card': 'var(--radius-card)',
        'modal': 'var(--radius-modal)',
        'btn': 'var(--radius-btn)',
        'input': 'var(--radius-input)',
      },
      overflow: {
        'x-visible': 'visible',
      },
    },
  },
  plugins: [],
};
