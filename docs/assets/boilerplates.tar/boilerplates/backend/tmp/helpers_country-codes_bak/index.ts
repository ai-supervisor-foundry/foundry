import { countryCodePairs } from 'src/assets/constants/country-codes-iso.constant';

export const getCountryName = (countryCode: string) => {
  const useCountry = countryCodePairs.find((pair) => pair.code === countryCode);
  return useCountry?.country || countryCode;
};
