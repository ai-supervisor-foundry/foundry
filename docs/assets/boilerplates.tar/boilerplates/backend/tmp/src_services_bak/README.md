# Services Directory

This directory is part of the basic project structure. In this NestJS project, services are organized by feature in the `src/modules/` directory.

## NestJS Structure

Services are located in their respective modules:
- `src/modules/auth/auth.service.ts`
- `src/modules/users/users.service.ts`
- `src/modules/listings/listings.service.ts`
- `src/modules/storage/storage.service.ts`
- And other feature modules...

Each module follows NestJS conventions with its own controller, service, and related files.
