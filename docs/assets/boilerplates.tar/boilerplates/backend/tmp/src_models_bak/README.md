# Models Directory

This directory is part of the basic project structure. In this NestJS project, models (entities) are organized in the `src/db/entities/` directory and within feature modules.

## NestJS Structure

Entities/Models are located in:
- `src/db/entities/` - Core database entities
- `src/modules/*/entities/` - Feature-specific entities

Examples:
- `src/db/entities/user.entity.ts`
- `src/modules/subscription/entities/subscription.entity.ts`
- `src/modules/listings/entities/listing.entity.ts`

Each entity follows TypeORM conventions for database modeling.
