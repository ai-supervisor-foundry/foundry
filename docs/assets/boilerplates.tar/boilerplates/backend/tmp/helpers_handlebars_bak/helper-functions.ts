import Handlebars from 'handlebars';

export interface IHelperFunction {
  [key: string]: (...args: any[]) => any;
}

export interface IHelperFunctionsCollections {
  [componentOrUsage: 'defaults' | string]: IHelperFunction;
}

export const helperFunctions: IHelperFunctionsCollections = {
  defaults: {
    helperMissing: function (...args) {
      const options = args[args.length - 1];
      return new Handlebars.SafeString(
        '[[ VALUE_NOT_SET: ' + options.name + ' ]]',
      );
    },
  },
  quotePdf: {
    isArray: function (value) {
      return Array.isArray(value);
    },

    titleCase: function (str = '') {
      return str.toLowerCase().replace(/\b(\w)/g, (s) => s.toUpperCase());
    },

    formatNumber: function (value) {
      if (typeof value !== 'number') {
        return value; // Return the original value if it's not a number
      }

      return new Intl.NumberFormat('en-US').format(value);
    },

    formatDate: function (date) {
      const suffixes = ['th', 'st', 'nd', 'rd'];
      date = new Date(date);
      const day = date.getDate();
      const daySuffix =
        day % 10 <= 3 && ![11, 12, 13].includes(day % 100)
          ? suffixes[day % 10]
          : suffixes[0];
      const month = date.toLocaleString('en-US', { month: 'short' });
      const year = date.getFullYear();
      return `${month} ${day}${daySuffix}, ${year}`;
    },

    ifEquals: function (arg1, arg2) {
      console.log('ifEquals', arg1, arg2, ' => ', arg1 === arg2);

      return arg1 == arg2 ? true : false;
    },

    orOp: function (...args) {
      args.pop();

      const reduced = args.reduce((p, a) => p || a, false);

      console.log('orOp', args, ' => ', reduced, '\n-------------------');

      return reduced;
    },

    orReturn: function (arg1, condition1, arg2) {
      console.log('orReturn', arg1, arg2, ' => ', arg1 || arg2);

      if (condition1) return arg1;
      return arg2;
    },

    andOp: function (...args) {
      args.pop();

      const reduced = args.reduce((p, a) => p && a, true);

      console.log('andOp', args, ' => ', reduced);

      return reduced;
    },

    lte: function (arg1, arg2) {
      console.log('lte', arg1, arg2, ' => ', arg1 <= arg2);

      return arg1 <= arg2;
    },

    gt: function (arg1, arg2) {
      console.log('gt', arg1, arg2, ' => ', arg1 > arg2);

      return arg1 > arg2;
    },

    mod: function (arg1, arg2) {
      console.log('mod', arg1, arg2, ' => ', arg1 % arg2);
      return arg1 % arg2;
    },

    subtract: function (arg1, arg2) {
      return arg1 - arg2;
    },

    helperMissing: function (...args) {
      const options = args[args.length - 1];
      return new Handlebars.SafeString(
        '[[ VALUE_NOT_SET: ' + options.name + ' ]]',
      );
    },
  },
};
