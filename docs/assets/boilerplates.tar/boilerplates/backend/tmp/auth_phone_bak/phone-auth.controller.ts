import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Req,
  Param,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
} from '@nestjs/swagger';
import type { Request } from 'express';
import { PhoneAuthService } from './phone-auth.service';
import {
  RequestOTPDto,
  VerifyOTPDto,
  ResendOTPDto,
  RequestOTPResponseDto,
  VerifyOTPResponseDto,
  PhoneValidationResultDto,
  RefreshTokenDto,
  RefreshTokenResponseDto,
} from './dto/phone-auth.dto';
import {
  ThrottleOTPRequest,
  ThrottleOTPVerify,
  ThrottleAuth,
} from './decorators/throttle-otp.decorator';
import { JwtAuthGuard, Public, AuthenticatedRequest } from './guards/jwt-auth.guard';

@ApiTags('auth/phone')
@Controller('auth/phone')
export class PhoneAuthController {
  constructor(private readonly phoneAuthService: PhoneAuthService) {}

  @Post('validate')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Validate a phone number' })
  @ApiResponse({
    status: 200,
    description: 'Validation result',
    type: PhoneValidationResultDto,
  })
  async validatePhone(
    @Body() body: { phoneNumber: string; defaultCountry?: string },
  ): Promise<PhoneValidationResultDto> {
    return this.phoneAuthService.validatePhoneNumber(
      body.phoneNumber,
      body.defaultCountry,
    );
  }

  @Post('request-otp')
  @Public()
  @ThrottleOTPRequest()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Request OTP for phone authentication' })
  @ApiResponse({
    status: 200,
    description: 'OTP sent successfully',
    type: RequestOTPResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid phone number or rate limited' })
  @ApiResponse({ status: 429, description: 'Too many requests' })
  async requestOTP(
    @Body() dto: RequestOTPDto,
    @Req() req: Request,
  ): Promise<RequestOTPResponseDto> {
    const ipAddress =
      (req.headers['x-forwarded-for'] as string) || req.ip || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    return this.phoneAuthService.sendOTP(dto, ipAddress, userAgent);
  }

  @Post('verify-otp')
  @Public()
  @ThrottleOTPVerify()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify OTP and authenticate' })
  @ApiResponse({
    status: 200,
    description: 'Authentication successful',
    type: VerifyOTPResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Invalid or expired OTP' })
  @ApiResponse({ status: 429, description: 'Too many attempts' })
  async verifyOTP(
    @Body() dto: VerifyOTPDto,
    @Req() req: Request,
  ): Promise<VerifyOTPResponseDto> {
    const ipAddress =
      (req.headers['x-forwarded-for'] as string) || req.ip || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    return this.phoneAuthService.verifyOTP(dto, ipAddress, userAgent);
  }

  @Post('resend-otp')
  @Public()
  @ThrottleOTPRequest()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Resend OTP' })
  @ApiResponse({
    status: 200,
    description: 'OTP resent successfully',
    type: RequestOTPResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Rate limited' })
  @ApiResponse({ status: 429, description: 'Too many requests' })
  async resendOTP(
    @Body() dto: ResendOTPDto,
    @Req() req: Request,
  ): Promise<RequestOTPResponseDto> {
    const ipAddress =
      (req.headers['x-forwarded-for'] as string) || req.ip || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    return this.phoneAuthService.resendOTP(
      dto.phoneNumber,
      dto.purpose,
      ipAddress,
      userAgent,
    );
  }

  @Post('refresh')
  @Public()
  @ThrottleAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Refresh access token' })
  @ApiResponse({
    status: 200,
    description: 'Token refreshed successfully',
    type: RefreshTokenResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Invalid or expired refresh token' })
  async refreshToken(
    @Body() dto: RefreshTokenDto,
  ): Promise<RefreshTokenResponseDto> {
    const result = await this.phoneAuthService.refreshAccessToken(dto.refreshToken);
    return {
      accessToken: result.accessToken,
      expiresIn: 900, // 15 minutes
    };
  }

  @Get('sessions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get active sessions for current user' })
  @ApiResponse({ status: 200, description: 'List of active sessions' })
  async getSessions(@Req() req: AuthenticatedRequest) {
    const sessions = await this.phoneAuthService.getUserSessions(req.user.id);
    return sessions.map((session) => ({
      id: session.id,
      deviceId: session.deviceId,
      userAgent: session.userAgent,
      ipAddress: session.ipAddress,
      createdAt: session.createdAt,
      lastActiveAt: session.lastActiveAt,
      isCurrent: session.id === req.user.sessionId,
    }));
  }

  @Delete('sessions/:sessionId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Revoke a specific session' })
  @ApiResponse({ status: 204, description: 'Session revoked' })
  async revokeSession(
    @Param('sessionId') sessionId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<void> {
    // Ensure user can only revoke their own sessions
    const sessions = await this.phoneAuthService.getUserSessions(req.user.id);
    const session = sessions.find((s) => s.id === sessionId);
    if (session) {
      await this.phoneAuthService.revokeSession(sessionId, 'User initiated');
    }
  }

  @Delete('sessions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Revoke all sessions (logout everywhere)' })
  @ApiResponse({ status: 204, description: 'All sessions revoked' })
  async revokeAllSessions(@Req() req: AuthenticatedRequest): Promise<void> {
    await this.phoneAuthService.revokeAllUserSessions(
      req.user.id,
      'Logout from all devices',
    );
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Logout current session' })
  @ApiResponse({ status: 204, description: 'Logged out successfully' })
  async logout(@Req() req: AuthenticatedRequest): Promise<void> {
    await this.phoneAuthService.revokeSession(req.user.sessionId, 'User logout');
  }
}
