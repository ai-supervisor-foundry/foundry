import { IsString, IsEnum, IsOptional, Matches, Length } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export enum OTPPurpose {
  LOGIN = 'login',
  REGISTRATION = 'registration',
  PASSWORD_RESET = 'password_reset',
  PHONE_VERIFICATION = 'phone_verification',
}

export class RequestOTPDto {
  @ApiProperty({
    description: 'Phone number in E.164 format or local format',
    example: '+923001234567',
  })
  @IsString()
  phoneNumber: string;

  @ApiPropertyOptional({
    description: 'Default country code for local numbers (ISO 3166-1 alpha-2)',
    example: 'PK',
    default: 'PK',
  })
  @IsOptional()
  @IsString()
  @Length(2, 2)
  defaultCountry?: string = 'PK';

  @ApiProperty({ enum: OTPPurpose, default: OTPPurpose.LOGIN })
  @IsEnum(OTPPurpose)
  purpose: OTPPurpose = OTPPurpose.LOGIN;
}

export class VerifyOTPDto {
  @ApiProperty({
    description: 'Phone number in E.164 format',
    example: '+923001234567',
  })
  @IsString()
  phoneNumber: string;

  @ApiProperty({
    description: '6-digit OTP code',
    example: '123456',
  })
  @IsString()
  @Matches(/^\d{6}$/, { message: 'OTP must be a 6-digit number' })
  otp: string;

  @ApiPropertyOptional({
    description: 'Device identifier for multi-device tracking',
  })
  @IsOptional()
  @IsString()
  deviceId?: string;
}

export class ResendOTPDto {
  @ApiProperty({
    description: 'Phone number in E.164 format',
    example: '+923001234567',
  })
  @IsString()
  phoneNumber: string;

  @ApiProperty({ enum: OTPPurpose, default: OTPPurpose.LOGIN })
  @IsEnum(OTPPurpose)
  purpose: OTPPurpose = OTPPurpose.LOGIN;
}

export class RefreshTokenDto {
  @ApiProperty({
    description: 'Refresh token',
  })
  @IsString()
  refreshToken: string;
}

export class RequestOTPResponseDto {
  @ApiProperty()
  success: boolean;

  @ApiProperty()
  message: string;

  @ApiProperty({ description: 'Seconds until OTP expires' })
  expiresIn: number;

  @ApiPropertyOptional({ description: 'Seconds until can request again' })
  retryAfter?: number;
}

export class VerifyOTPResponseDto {
  @ApiProperty()
  success: boolean;

  @ApiProperty()
  accessToken: string;

  @ApiProperty()
  user: {
    id: string;
    phoneNumber: string;
    phoneVerified: boolean;
    tier: string;
    isNewUser: boolean;
  };

  @ApiProperty()
  session: {
    id: string;
    expiresAt: string;
  };
}

export class RefreshTokenResponseDto {
  @ApiProperty()
  accessToken: string;

  @ApiProperty({ description: 'Seconds until token expires' })
  expiresIn: number;
}

export class PhoneValidationResultDto {
  @ApiProperty()
  isValid: boolean;

  @ApiPropertyOptional()
  normalizedNumber?: string;

  @ApiPropertyOptional()
  countryCode?: string;

  @ApiPropertyOptional()
  countryCallingCode?: string;

  @ApiPropertyOptional()
  nationalNumber?: string;

  @ApiPropertyOptional()
  numberType?: 'mobile' | 'landline' | 'unknown';

  @ApiPropertyOptional()
  error?: {
    code: string;
    message: string;
  };
}

export class SessionInfoDto {
  @ApiProperty()
  id: string;

  @ApiPropertyOptional()
  deviceId?: string;

  @ApiPropertyOptional()
  userAgent?: string;

  @ApiPropertyOptional()
  ipAddress?: string;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  lastActiveAt: Date;

  @ApiProperty()
  isCurrent: boolean;
}
