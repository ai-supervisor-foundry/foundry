import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { EnvProps } from '../../../env';

export interface SMSResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private readonly twilioClient: any;
  private readonly messagingServiceSid: string;
  private readonly senderId: string;
  private readonly isEnabled: boolean;
  private readonly isDevSandbox: boolean;

  constructor(private readonly configService: ConfigService<EnvProps, true>) {
    const accountSid = this.configService.get('TWILIO_ACCOUNT_SID', { infer: true });
    const authToken = this.configService.get('TWILIO_AUTH_TOKEN', { infer: true });
    this.messagingServiceSid = this.configService.get('TWILIO_MESSAGING_SERVICE_SID', { infer: true }) || '';
    this.senderId = this.configService.get('TWILIO_SENDER_ID', { infer: true }) || 'EaseClass';

    // Determine dev sandbox mode: defaults to true if NODE_ENV is 'development', false otherwise
    const nodeEnv = this.configService.get('NODE_ENV', { infer: true });
    const isDevSandboxEnv = this.configService.get('IS_DEV_SANDBOX', { infer: true });
    this.isDevSandbox =
      isDevSandboxEnv === 'true' || (isDevSandboxEnv === undefined && nodeEnv === 'development');

    // Only initialize Twilio if credentials are provided
    this.isEnabled = !!(accountSid && authToken);

    if (this.isEnabled) {
      try {
        // Dynamic import to avoid errors when Twilio is not installed
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const Twilio = require('twilio');
        this.twilioClient = new Twilio(accountSid, authToken);
        this.logger.log('Twilio SMS service initialized');
      } catch (error) {
        this.logger.warn('Twilio SDK not available, SMS service disabled');
        this.isEnabled = false;
      }
    } else {
      this.logger.warn('Twilio credentials not configured, SMS service disabled');
    }
  }

  /**
   * Send OTP via SMS
   */
  async sendOTP(phoneNumber: string, otp: string): Promise<SMSResult> {
    const message = this.formatOTPMessage(otp);

    if (this.isDevSandbox) {
      // Development/Sandbox mode - log OTP instead of sending
      this.logger.log(`[DEV SANDBOX MODE] OTP for ${phoneNumber}: ${otp}`);
      return {
        success: true,
        messageId: `dev_${Date.now()}`,
      };
    }

    if (!this.isEnabled) {
      this.logger.warn('SMS service is disabled and not in dev sandbox mode');
      return {
        success: false,
        error: 'SMS service is not configured',
      };
    }

    return this.sendSMS(phoneNumber, message);
  }

  /**
   * Send SMS message via Twilio
   */
  async sendSMS(to: string, body: string): Promise<SMSResult> {
    if (!this.isEnabled) {
      this.logger.warn('SMS service is disabled');
      return {
        success: false,
        error: 'SMS service is not configured',
      };
    }

    try {
      const messageOptions: any = {
        to,
        body,
      };

      // Use messaging service if available, otherwise use sender ID
      if (this.messagingServiceSid) {
        messageOptions.messagingServiceSid = this.messagingServiceSid;
      } else {
        messageOptions.from = this.senderId;
      }

      const message = await this.twilioClient.messages.create(messageOptions);

      this.logger.log(`SMS sent to ${to}, SID: ${message.sid}`);

      return {
        success: true,
        messageId: message.sid,
      };
    } catch (error: any) {
      this.logger.error(`Failed to send SMS to ${to}: ${error.message}`);

      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Format OTP message
   */
  private formatOTPMessage(otp: string): string {
    return `Your EaseClassifieds verification code is: ${otp}\n\nThis code expires in 7 minutes. Do not share this code with anyone.`;
  }

  /**
   * Check if SMS service is enabled
   */
  isServiceEnabled(): boolean {
    return this.isEnabled;
  }
}
