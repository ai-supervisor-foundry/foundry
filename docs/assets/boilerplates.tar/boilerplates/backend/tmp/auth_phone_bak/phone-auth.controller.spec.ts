import { Test, TestingModule } from '@nestjs/testing';
import { PhoneAuthController } from './phone-auth.controller';
import { PhoneAuthService } from './phone-auth.service';
import {
  RequestOTPDto,
  VerifyOTPDto,
  ResendOTPDto,
  RequestOTPResponseDto,
  VerifyOTPResponseDto,
  PhoneValidationResultDto,
  RefreshTokenDto,
  RefreshTokenResponseDto,
} from './dto/phone-auth.dto';

describe('PhoneAuthController', () => {
  let controller: PhoneAuthController;
  let phoneAuthService: PhoneAuthService;

  const mockPhoneAuthService = {
    validatePhoneNumber: jest.fn(),
    sendOTP: jest.fn(),
    verifyOTP: jest.fn(),
    resendOTP: jest.fn(),
    refreshAccessToken: jest.fn(),
    getUserSessions: jest.fn(),
    revokeSession: jest.fn(),
    revokeAllUserSessions: jest.fn(),
  };

  const mockRequest = {
    headers: {
      'x-forwarded-for': '127.0.0.1',
      'user-agent': 'test-agent',
    },
    ip: '127.0.0.1',
    user: {
      id: 1,
      sessionId: 'session-id',
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PhoneAuthController],
      providers: [
        {
          provide: PhoneAuthService,
          useValue: mockPhoneAuthService,
        },
      ],
    }).compile();

    controller = module.get<PhoneAuthController>(PhoneAuthController);
    phoneAuthService = module.get<PhoneAuthService>(PhoneAuthService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('validatePhone', () => {
    it('should validate phone number', async () => {
      const mockResult: PhoneValidationResultDto = {
        isValid: true,
        normalized: '+923001234567',
        countryCode: 'PK',
        format: 'E.164',
      };

      jest.spyOn(phoneAuthService, 'validatePhoneNumber').mockReturnValue(mockResult);

      const result = await controller.validatePhone({
        phoneNumber: '03001234567',
        defaultCountry: 'PK',
      });

      expect(result).toEqual(mockResult);
      expect(phoneAuthService.validatePhoneNumber).toHaveBeenCalledWith(
        '03001234567',
        'PK',
      );
    });
  });

  describe('requestOTP', () => {
    it('should request OTP', async () => {
      const dto: RequestOTPDto = {
        phoneNumber: '+923001234567',
        purpose: 'LOGIN',
      };

      const mockResponse: RequestOTPResponseDto = {
        success: true,
        message: 'OTP sent successfully',
        expiresIn: 420,
        retryAfter: 60,
      };

      jest.spyOn(phoneAuthService, 'sendOTP').mockResolvedValue(mockResponse);

      const result = await controller.requestOTP(dto, mockRequest as any);

      expect(result).toEqual(mockResponse);
      expect(phoneAuthService.sendOTP).toHaveBeenCalledWith(
        dto,
        '127.0.0.1',
        'test-agent',
      );
    });
  });

  describe('verifyOTP', () => {
    it('should verify OTP and authenticate', async () => {
      const dto: VerifyOTPDto = {
        phoneNumber: '+923001234567',
        otp: '123456',
        purpose: 'LOGIN',
      };

      const mockResponse: VerifyOTPResponseDto = {
        accessToken: 'access-token',
        refreshToken: 'refresh-token',
        expiresIn: 900,
        user: {
          id: 1,
          phone: '+923001234567',
          verified: true,
        } as any,
      };

      jest.spyOn(phoneAuthService, 'verifyOTP').mockResolvedValue(mockResponse);

      const result = await controller.verifyOTP(dto, mockRequest as any);

      expect(result).toEqual(mockResponse);
      expect(phoneAuthService.verifyOTP).toHaveBeenCalledWith(
        dto,
        '127.0.0.1',
        'test-agent',
      );
    });
  });

  describe('resendOTP', () => {
    it('should resend OTP', async () => {
      const dto: ResendOTPDto = {
        phoneNumber: '+923001234567',
        purpose: 'LOGIN',
      };

      const mockResponse: RequestOTPResponseDto = {
        success: true,
        message: 'OTP resent successfully',
        expiresIn: 420,
        retryAfter: 60,
      };

      jest.spyOn(phoneAuthService, 'resendOTP').mockResolvedValue(mockResponse);

      const result = await controller.resendOTP(dto, mockRequest as any);

      expect(result).toEqual(mockResponse);
      expect(phoneAuthService.resendOTP).toHaveBeenCalledWith(
        dto.phoneNumber,
        dto.purpose,
        '127.0.0.1',
        'test-agent',
      );
    });
  });

  describe('refreshToken', () => {
    it('should refresh access token', async () => {
      const dto: RefreshTokenDto = {
        refreshToken: 'refresh-token',
      };

      const mockResult = {
        accessToken: 'new-access-token',
        expiresIn: 900,
      };

      jest.spyOn(phoneAuthService, 'refreshAccessToken').mockResolvedValue(mockResult);

      const result = await controller.refreshToken(dto);

      expect(result).toEqual({
        accessToken: 'new-access-token',
        expiresIn: 900,
      });
      expect(phoneAuthService.refreshAccessToken).toHaveBeenCalledWith(dto.refreshToken);
    });
  });

  describe('getSessions', () => {
    it('should get user sessions', async () => {
      const mockSessions = [
        {
          id: 'session-1',
          deviceId: 'device-1',
          userAgent: 'test-agent',
          ipAddress: '127.0.0.1',
          createdAt: new Date(),
          lastActiveAt: new Date(),
        },
      ];

      jest.spyOn(phoneAuthService, 'getUserSessions').mockResolvedValue(mockSessions as any);

      const result = await controller.getSessions(mockRequest as any);

      expect(result).toHaveLength(1);
      expect(result[0]).toHaveProperty('isCurrent', false);
      expect(phoneAuthService.getUserSessions).toHaveBeenCalledWith(1);
    });
  });

  describe('revokeSession', () => {
    it('should revoke a session', async () => {
      const mockSessions = [
        {
          id: 'session-1',
          deviceId: 'device-1',
        },
      ];

      jest.spyOn(phoneAuthService, 'getUserSessions').mockResolvedValue(mockSessions as any);
      jest.spyOn(phoneAuthService, 'revokeSession').mockResolvedValue(undefined);

      await controller.revokeSession('session-1', mockRequest as any);

      expect(phoneAuthService.revokeSession).toHaveBeenCalledWith('session-1', 'User initiated');
    });
  });

  describe('revokeAllSessions', () => {
    it('should revoke all sessions', async () => {
      jest.spyOn(phoneAuthService, 'revokeAllUserSessions').mockResolvedValue(undefined);

      await controller.revokeAllSessions(mockRequest as any);

      expect(phoneAuthService.revokeAllUserSessions).toHaveBeenCalledWith(
        1,
        'Logout from all devices',
      );
    });
  });

  describe('logout', () => {
    it('should logout current session', async () => {
      jest.spyOn(phoneAuthService, 'revokeSession').mockResolvedValue(undefined);

      await controller.logout(mockRequest as any);

      expect(phoneAuthService.revokeSession).toHaveBeenCalledWith('session-id', 'User logout');
    });
  });
});
