import { applyDecorators, SetMetadata } from '@nestjs/common';
import { Throttle, SkipThrottle } from '@nestjs/throttler';

/**
 * Rate limiting configuration for OTP endpoints
 * Based on the PHONE_AUTHENTICATION_SYSTEM.md specification:
 * - OTP Request: 1/min per phone, 5/hour per phone, 10/day per phone
 * - OTP Verification: 3 attempts per OTP instance
 * - IP Rate Limit: 10/min per IP, 50/hour per IP
 */

// Custom throttler names for OTP-specific rate limiting
export const OTP_THROTTLE_KEY = 'otp';
export const PHONE_THROTTLE_KEY = 'phone';

/**
 * Check if rate limiting is disabled
 * DISABLE_RATE_LIMITS defaults to true if NODE_ENV is 'development', false otherwise
 */
function isRateLimitingDisabled(): boolean {
  const disableRateLimits = process.env.DISABLE_RATE_LIMITS;
  // If explicitly set, use that value
  if (disableRateLimits !== undefined) {
    return disableRateLimits === 'true';
  }
  // Otherwise, default to true in development, false otherwise
  return process.env.NODE_ENV === 'development';
}

/**
 * Apply strict rate limiting for OTP request endpoints
 * Rate limits are configurable via environment variables:
 * - OTP_RATE_LIMIT_SHORT: requests per minute (default: 1)
 * - OTP_RATE_LIMIT_MEDIUM: requests per hour (default: 5)
 * - OTP_RATE_LIMIT_LONG: requests per day (default: 10)
 * - DISABLE_RATE_LIMITS: if 'true', disables all rate limiting (defaults to true if NODE_ENV is 'development')
 */
export function ThrottleOTPRequest() {
  // Check if rate limits are disabled
  if (isRateLimitingDisabled()) {
    return applyDecorators(NoThrottle(), SetMetadata(OTP_THROTTLE_KEY, true));
  }

  const shortLimit = parseInt(process.env.OTP_RATE_LIMIT_SHORT || '1', 10);
  const mediumLimit = parseInt(process.env.OTP_RATE_LIMIT_MEDIUM || '5', 10);
  const longLimit = parseInt(process.env.OTP_RATE_LIMIT_LONG || '10', 10);

  return applyDecorators(
    Throttle({
      short: { limit: shortLimit, ttl: 60000 }, // per minute
      medium: { limit: mediumLimit, ttl: 3600000 }, // per hour
      long: { limit: longLimit, ttl: 86400000 }, // per day
    }),
    SetMetadata(OTP_THROTTLE_KEY, true),
  );
}

/**
 * Apply rate limiting for OTP verification endpoints
 * More lenient than request endpoint
 * - DISABLE_RATE_LIMITS: if 'true', disables all rate limiting (defaults to true if NODE_ENV is 'development')
 */
export function ThrottleOTPVerify() {
  // Check if rate limits are disabled
  if (isRateLimitingDisabled()) {
    return applyDecorators(NoThrottle(), SetMetadata(OTP_THROTTLE_KEY, true));
  }

  return applyDecorators(
    Throttle({
      short: { limit: 3, ttl: 60000 }, // 3 per minute
      medium: { limit: 10, ttl: 600000 }, // 10 per 10 minutes
    }),
    SetMetadata(OTP_THROTTLE_KEY, true),
  );
}

/**
 * Apply general auth rate limiting
 * - DISABLE_RATE_LIMITS: if 'true', disables all rate limiting (defaults to true if NODE_ENV is 'development')
 */
export function ThrottleAuth() {
  // Check if rate limits are disabled
  if (isRateLimitingDisabled()) {
    return applyDecorators(NoThrottle());
  }

  return applyDecorators(
    Throttle({
      short: { limit: 5, ttl: 60000 }, // 5 per minute
      medium: { limit: 30, ttl: 600000 }, // 30 per 10 minutes
    }),
  );
}

/**
 * Skip throttling for specific routes
 */
export function NoThrottle() {
  return SkipThrottle();
}

/**
 * Apply rate limiting for sensitive endpoints (subscription, payment, password changes)
 * Stricter than general auth to prevent abuse
 * - DISABLE_RATE_LIMITS: if 'true', disables all rate limiting (defaults to true if NODE_ENV is 'development')
 */
export function ThrottleSensitive() {
  // Check if rate limits are disabled
  if (isRateLimitingDisabled()) {
    return applyDecorators(NoThrottle());
  }

  return applyDecorators(
    Throttle({
      short: { limit: 3, ttl: 60000 }, // 3 per minute
      medium: { limit: 10, ttl: 600000 }, // 10 per 10 minutes
      long: { limit: 20, ttl: 3600000 }, // 20 per hour
    }),
  );
}

/**
 * Custom throttle configuration
 */
export function CustomThrottle(
  short?: { limit: number; ttl: number },
  medium?: { limit: number; ttl: number },
  long?: { limit: number; ttl: number },
) {
  const config: any = {};
  if (short) config.short = short;
  if (medium) config.medium = medium;
  if (long) config.long = long;
  
  return Throttle(config);
}
