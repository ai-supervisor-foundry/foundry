import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { EnvProps } from '../../../../env';
import { JwtPayload } from '../guards/jwt-auth.guard';
import { UsersService } from '../../../users/users.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(
    private readonly configService: ConfigService<EnvProps, true>,
    private readonly usersService: UsersService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get('JWT_SECRET'),
    });
  }

  async validate(payload: JwtPayload): Promise<JwtPayload> {
    // Validate token type for phone auth tokens (email/password tokens don't have type)
    // Only validate type if it exists in the payload
    if ('type' in payload && payload.type && payload.type !== 'access') {
      throw new UnauthorizedException('Invalid token type');
    }

    // Get user ID from either 'sub' (phone auth) or 'id' (email/password auth)
    const userId = 'sub' in payload ? payload.sub : ('id' in payload ? payload.id : null);
    if (!userId) {
      throw new UnauthorizedException('Invalid token payload structure');
    }

    // Optionally validate user exists
    const user = await this.usersService.findById(userId);
    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    return payload;
  }
}
