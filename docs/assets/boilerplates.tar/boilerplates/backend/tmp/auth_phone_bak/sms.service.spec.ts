import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { SmsService } from './sms.service';

describe('SmsService', () => {
  let service: SmsService;
  let configService: ConfigService;

  const mockConfigService = {
    get: jest.fn((key: string) => {
      const config: Record<string, any> = {
        TWILIO_ACCOUNT_SID: 'test_account_sid',
        TWILIO_AUTH_TOKEN: 'test_auth_token',
        TWILIO_MESSAGING_SERVICE_SID: 'test_messaging_service_sid',
        TWILIO_SENDER_ID: 'EaseClass',
      };
      return config[key];
    }),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SmsService,
        {
          provide: ConfigService,
          useValue: mockConfigService,
        },
      ],
    }).compile();

    service = module.get<SmsService>(SmsService);
    configService = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('sendOTP', () => {
    it('should send OTP in development mode when service is disabled', async () => {
      // Mock service as disabled
      jest.spyOn(service, 'isServiceEnabled').mockReturnValue(false);

      const result = await service.sendOTP('+1234567890', '123456');

      expect(result.success).toBe(true);
      expect(result.messageId).toContain('dev_');
    });

    it('should format OTP message correctly', async () => {
      jest.spyOn(service, 'isServiceEnabled').mockReturnValue(false);

      const result = await service.sendOTP('+1234567890', '123456');

      expect(result.success).toBe(true);
    });
  });

  describe('sendSMS', () => {
    it('should return error when service is disabled', async () => {
      jest.spyOn(service, 'isServiceEnabled').mockReturnValue(false);

      const result = await service.sendSMS('+1234567890', 'Test message');

      expect(result.success).toBe(false);
      expect(result.error).toBe('SMS service is not configured');
    });
  });

  describe('isServiceEnabled', () => {
    it('should return false when credentials are not configured', () => {
      const disabledConfigService = {
        get: jest.fn(() => null),
      };

      const disabledModule = Test.createTestingModule({
        providers: [
          SmsService,
          {
            provide: ConfigService,
            useValue: disabledConfigService,
          },
        ],
      });

      return disabledModule.compile().then((module) => {
        const disabledService = module.get<SmsService>(SmsService);
        expect(disabledService.isServiceEnabled()).toBe(false);
      });
    });
  });
});
