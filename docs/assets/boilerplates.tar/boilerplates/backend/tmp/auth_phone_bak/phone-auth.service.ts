import {
  Injectable,
  BadRequestException,
  UnauthorizedException,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { randomInt, randomUUID } from 'crypto';
import { hashSync, compareSync } from 'bcrypt';
import { InMemoryCacheService } from './in-memory-cache.service';
import { UsersService } from '../../users/users.service';
import { SmsService } from './sms.service';
import { OTPAudit, OTPAction, OTPPurpose as EntityOTPPurpose } from './entities/otp-audit.entity';
import { UserSession } from './entities/user-session.entity';
import { OTP } from './entities/otp.entity';
import {
  RequestOTPDto,
  VerifyOTPDto,
  RequestOTPResponseDto,
  VerifyOTPResponseDto,
  PhoneValidationResultDto,
  OTPPurpose,
} from './dto/phone-auth.dto';
import { EnvProps } from '../../../env';

interface OTPRecord {
  otpHash: string;
  purpose: OTPPurpose;
  attemptCount: number;
  maxAttempts: number;
  createdAt: string;
  expiresAt: string;
  ipAddress: string;
  userAgent: string;
}

interface RateLimitInfo {
  count: number;
  resetAt: string;
}

// Supported country configurations
const SUPPORTED_COUNTRIES: Record<string, { code: string; mobilePrefixes: string[] }> = {
  PK: { code: '92', mobilePrefixes: ['30', '31', '32', '33', '34', '35', '36', '37', '38', '39'] },
  AE: { code: '971', mobilePrefixes: ['50', '52', '54', '55', '56', '58'] },
  SA: { code: '966', mobilePrefixes: ['50', '53', '54', '55', '56', '57', '58', '59'] },
  QA: { code: '974', mobilePrefixes: ['30', '31', '32', '33', '34', '55', '66', '77'] },
  KW: { code: '965', mobilePrefixes: ['50', '51', '52', '54', '55', '56', '57', '58', '59', '60', '61', '65', '66', '67', '69'] },
  BH: { code: '973', mobilePrefixes: ['30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '66', '67', '68', '69'] },
  OM: { code: '968', mobilePrefixes: ['90', '91', '92', '93', '94', '95', '96', '97', '98', '99'] },
};

@Injectable()
export class PhoneAuthService {
  private readonly logger = new Logger(PhoneAuthService.name);
  private readonly otpLength: number;
  private readonly otpExpiryMinutes: number;
  private readonly maxAttempts: number;
  private readonly cooldownMinutes: number;
  private readonly accessTokenExpiry: string;
  private readonly refreshTokenExpiry: string;

  constructor(
    private readonly configService: ConfigService<EnvProps, true>,
    private readonly jwtService: JwtService,
    private readonly cacheService: InMemoryCacheService,
    private readonly usersService: UsersService,
    private readonly smsService: SmsService,
    @InjectRepository(OTPAudit)
    private readonly otpAuditRepository: Repository<OTPAudit>,
    @InjectRepository(UserSession)
    private readonly userSessionRepository: Repository<UserSession>,
    @InjectRepository(OTP)
    private readonly otpRepository: Repository<OTP>,
  ) {
    // Load configuration with defaults
    this.otpLength = parseInt(this.configService.get('OTP_LENGTH', { infer: true }) || '6', 10);
    // Ensure OTP expiry is between 5-10 minutes
    const expiryMinutes = parseInt(this.configService.get('OTP_EXPIRY_MINUTES', { infer: true }) || '7', 10);
    this.otpExpiryMinutes = Math.max(5, Math.min(10, expiryMinutes));
    this.maxAttempts = parseInt(this.configService.get('OTP_MAX_ATTEMPTS', { infer: true }) || '3', 10);
    this.cooldownMinutes = parseInt(this.configService.get('OTP_COOLDOWN_MINUTES', { infer: true }) || '15', 10);
    this.accessTokenExpiry = this.configService.get('JWT_ACCESS_TOKEN_EXPIRY', { infer: true }) || '15m';
    this.refreshTokenExpiry = this.configService.get('JWT_REFRESH_TOKEN_EXPIRY', { infer: true }) || '30d';
  }

  /**
   * Validate and normalize phone number to E.164 format
   */
  validatePhoneNumber(
    phoneNumber: string,
    defaultCountry: string = 'PK',
  ): PhoneValidationResultDto {
    // Remove all whitespace and special characters except +
    let cleaned = phoneNumber.replace(/[\s\-\(\)]/g, '');

    // Handle different input formats
    if (cleaned.startsWith('00')) {
      cleaned = '+' + cleaned.substring(2);
    } else if (!cleaned.startsWith('+')) {
      // Check if it starts with country code without +
      const countryConfig = SUPPORTED_COUNTRIES[defaultCountry];
      if (countryConfig) {
        if (cleaned.startsWith(countryConfig.code)) {
          cleaned = '+' + cleaned;
        } else if (cleaned.startsWith('0')) {
          // Local format with leading 0
          cleaned = '+' + countryConfig.code + cleaned.substring(1);
        } else {
          cleaned = '+' + countryConfig.code + cleaned;
        }
      }
    }

    // Extract country code and national number
    let countryCode: string | null = null;
    let countryCallingCode: string | null = null;
    let nationalNumber: string | null = null;

    for (const [code, config] of Object.entries(SUPPORTED_COUNTRIES)) {
      if (cleaned.startsWith('+' + config.code)) {
        countryCode = code;
        countryCallingCode = config.code;
        nationalNumber = cleaned.substring(1 + config.code.length);
        break;
      }
    }

    if (!countryCode || !nationalNumber) {
      return {
        isValid: false,
        error: {
          code: 'INVALID_COUNTRY',
          message: 'Phone number country is not supported',
        },
      };
    }

    // Validate national number length (7-10 digits for supported countries)
    if (nationalNumber.length < 7 || nationalNumber.length > 10) {
      return {
        isValid: false,
        error: {
          code: nationalNumber.length < 7 ? 'TOO_SHORT' : 'TOO_LONG',
          message: `Phone number has invalid length: ${nationalNumber.length} digits`,
        },
      };
    }

    // Check if it's a mobile number
    const countryConfig = SUPPORTED_COUNTRIES[countryCode];
    const prefix = nationalNumber.substring(0, 2);
    const isMobile = countryConfig.mobilePrefixes.includes(prefix);

    if (!isMobile) {
      return {
        isValid: false,
        error: {
          code: 'NOT_MOBILE',
          message: 'Only mobile phone numbers are accepted',
        },
      };
    }

    return {
      isValid: true,
      normalizedNumber: cleaned,
      countryCode,
      countryCallingCode,
      nationalNumber,
      numberType: 'mobile',
    };
  }

  /**
   * Generate a cryptographically secure OTP
   */
  private generateOTP(): string {
    const otp = randomInt(0, Math.pow(10, this.otpLength));
    return otp.toString().padStart(this.otpLength, '0');
  }

  /**
   * Send OTP for phone authentication
   */
  async sendOTP(
    dto: RequestOTPDto,
    ipAddress: string,
    userAgent: string,
  ): Promise<RequestOTPResponseDto> {
    // Validate phone number
    const validation = this.validatePhoneNumber(dto.phoneNumber, dto.defaultCountry);
    if (!validation.isValid) {
      throw new BadRequestException(validation.error?.message);
    }

    const normalizedPhone = validation.normalizedNumber!;

    // Check rate limiting
    await this.checkRateLimits(normalizedPhone, ipAddress);

    // Generate OTP
    const otp = this.generateOTP();
    const otpHash = hashSync(otp, 10);

    // Calculate expiration - ensure it's between 5-10 minutes from now
    const now = new Date();
    const expirationMs = this.otpExpiryMinutes * 60 * 1000;
    const expiresAt = new Date(now.getTime() + expirationMs);
    
    // Verify expiration is within 5-10 minutes range (in seconds)
    const expirationSeconds = Math.floor((expiresAt.getTime() - now.getTime()) / 1000);
    if (expirationSeconds < 300 || expirationSeconds > 600) {
      this.logger.warn(
        `OTP expiration ${expirationSeconds}s is outside 5-10 minute range. Adjusting to 7 minutes.`,
      );
      // Fallback to 7 minutes if somehow out of range
      const fallbackExpirationMs = 7 * 60 * 1000;
      expiresAt.setTime(now.getTime() + fallbackExpirationMs);
    }

    // Store OTP record in Redis
    const otpRecord: OTPRecord = {
      otpHash,
      purpose: dto.purpose,
      attemptCount: 0,
      maxAttempts: this.maxAttempts,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      ipAddress,
      userAgent,
    };

    const cacheKey = this.getOTPCacheKey(normalizedPhone, dto.purpose);
    await this.cacheService.setKey(
      cacheKey,
      JSON.stringify(otpRecord),
      this.otpExpiryMinutes * 60,
    );

    // Store OTP in database with expiration
    // First, invalidate any existing OTPs for this phone and purpose
    await this.otpRepository.update(
      {
        phoneNumber: normalizedPhone,
        purpose: dto.purpose as unknown as EntityOTPPurpose,
        isUsed: false,
      },
      { isUsed: true },
    );

    // Create new OTP record in database
    const otpEntity = this.otpRepository.create({
      phoneNumber: normalizedPhone,
      otpHash,
      purpose: dto.purpose as unknown as EntityOTPPurpose,
      attemptCount: 0,
      maxAttempts: this.maxAttempts,
      expiresAt,
      ipAddress,
      userAgent,
      isUsed: false,
    });
    const savedOTP = await this.otpRepository.save(otpEntity);
    
    // Verify expiration was saved correctly (within 5-10 minutes)
    if (savedOTP.expiresAt) {
      const savedExpirationSeconds = Math.floor(
        (savedOTP.expiresAt.getTime() - now.getTime()) / 1000,
      );
      if (savedExpirationSeconds < 300 || savedExpirationSeconds > 600) {
        this.logger.error(
          `OTP expiration saved incorrectly: ${savedExpirationSeconds}s (expected 300-600s)`,
        );
      } else {
        this.logger.debug(
          `OTP saved with expiration: ${savedExpirationSeconds}s (${Math.round(savedExpirationSeconds / 60)} minutes)`,
        );
      }
    } else {
      this.logger.error('OTP expiration not saved to database');
      throw new Error('Failed to save OTP expiration to database');
    }

    // Update rate limit counters
    await this.updateRateLimits(normalizedPhone, ipAddress);

    // Send SMS via Twilio
    const smsResult = await this.smsService.sendOTP(normalizedPhone, otp);

    // Log audit entry
    await this.logOTPAudit(
      normalizedPhone,
      dto.purpose as unknown as EntityOTPPurpose,
      smsResult.success ? OTPAction.SENT : OTPAction.FAILED,
      ipAddress,
      userAgent,
      0,
      smsResult.success,
      smsResult.error,
    );

    if (!smsResult.success) {
      this.logger.error(`Failed to send OTP to ${normalizedPhone}: ${smsResult.error}`);
      // In development, we still return success but log the error
      // In production, you might want to throw an error
    }

    this.logger.log(`OTP sent to ${normalizedPhone} (purpose: ${dto.purpose})`);

    return {
      success: true,
      message: 'OTP sent successfully',
      expiresIn: this.otpExpiryMinutes * 60,
    };
  }

  /**
   * Verify OTP and authenticate user
   */
  async verifyOTP(
    dto: VerifyOTPDto,
    ipAddress: string,
    userAgent: string,
  ): Promise<VerifyOTPResponseDto> {
    // Validate phone number
    const validation = this.validatePhoneNumber(dto.phoneNumber);
    if (!validation.isValid) {
      throw new BadRequestException(validation.error?.message);
    }

    const normalizedPhone = validation.normalizedNumber!;

    // Get OTP record from database (try both login and registration purposes)
    let otpEntity: OTP | null = null;
    let purpose: OTPPurpose | null = null;

    for (const p of [OTPPurpose.LOGIN, OTPPurpose.REGISTRATION]) {
      const found = await this.otpRepository.findOne({
        where: {
          phoneNumber: normalizedPhone,
          purpose: p as unknown as EntityOTPPurpose,
          isUsed: false,
        },
        order: { createdAt: 'DESC' },
      });
      if (found) {
        otpEntity = found;
        purpose = p;
        break;
      }
    }

    if (!otpEntity) {
      await this.logOTPAudit(
        normalizedPhone,
        EntityOTPPurpose.LOGIN,
        OTPAction.FAILED,
        ipAddress,
        userAgent,
        0,
        false,
        'OTP not found',
      );
      throw new UnauthorizedException('OTP expired or not found. Please request a new OTP.');
    }

    // Check if OTP is expired
    if (new Date() > otpEntity.expiresAt) {
      await this.otpRepository.update(otpEntity.id, { isUsed: true });
      await this.invalidateOTP(normalizedPhone, purpose!);
      await this.logOTPAudit(
        normalizedPhone,
        purpose as unknown as EntityOTPPurpose,
        OTPAction.EXPIRED,
        ipAddress,
        userAgent,
        otpEntity.attemptCount,
        false,
        'OTP expired',
      );
      throw new UnauthorizedException('OTP has expired. Please request a new OTP.');
    }

    // Check attempt limit
    if (otpEntity.attemptCount >= otpEntity.maxAttempts) {
      await this.otpRepository.update(otpEntity.id, { isUsed: true });
      await this.invalidateOTP(normalizedPhone, purpose!);
      await this.logOTPAudit(
        normalizedPhone,
        purpose as unknown as EntityOTPPurpose,
        OTPAction.BLOCKED,
        ipAddress,
        userAgent,
        otpEntity.attemptCount,
        false,
        'Max attempts exceeded',
      );
      throw new UnauthorizedException(
        `Maximum verification attempts exceeded. Please wait ${this.cooldownMinutes} minutes.`,
      );
    }

    // Verify OTP
    const isValid = compareSync(dto.otp, otpEntity.otpHash);

    if (!isValid) {
      // Increment attempt count in database
      otpEntity.attemptCount++;
      await this.otpRepository.update(otpEntity.id, {
        attemptCount: otpEntity.attemptCount,
      });

      await this.logOTPAudit(
        normalizedPhone,
        purpose as unknown as EntityOTPPurpose,
        OTPAction.FAILED,
        ipAddress,
        userAgent,
        otpEntity.attemptCount,
        false,
        'Invalid OTP',
      );

      const remainingAttempts = otpEntity.maxAttempts - otpEntity.attemptCount;
      throw new UnauthorizedException(
        `Invalid OTP. ${remainingAttempts} attempt(s) remaining.`,
      );
    }

    // OTP is valid - mark as used in database
    await this.otpRepository.update(otpEntity.id, { isUsed: true });
    await this.invalidateOTP(normalizedPhone, purpose!);

    // Log successful verification
    await this.logOTPAudit(
      normalizedPhone,
      purpose as unknown as EntityOTPPurpose,
      OTPAction.VERIFIED,
      ipAddress,
      userAgent,
      otpEntity.attemptCount,
      true,
    );

    // Find or create user
    let user = await this.usersService.findByPhone(normalizedPhone);
    let isNewUser = false;

    if (!user) {
      // Create new user on first login
      user = await this.usersService.createFromPhone(normalizedPhone);
      isNewUser = true;
      this.logger.log(`New user created from phone: ${normalizedPhone}`);
    }

    // Update phone verification status
    if (!user.verified) {
      await this.usersService.updatePhoneVerification(user.id, true);
    }

    // Generate session
    const sessionId = randomUUID();
    const tokenFamilyId = randomUUID();
    const sessionExpiry = new Date();
    sessionExpiry.setDate(sessionExpiry.getDate() + 30); // 30 days

    // Generate JWT access token
    const accessToken = this.jwtService.sign(
      {
        sub: user.id,
        type: 'access',
        phoneNumber: normalizedPhone,
        phoneVerified: true,
        tier: user.tier || 'free',
        role: user.role,
        sessionId,
      },
      { expiresIn: this.accessTokenExpiry },
    );

    // Generate refresh token
    const refreshToken = this.jwtService.sign(
      {
        sub: user.id,
        type: 'refresh',
        sessionId,
        familyId: tokenFamilyId,
        generation: 0,
      },
      { expiresIn: this.refreshTokenExpiry },
    );

    // Store session in database
    const session = this.userSessionRepository.create({
      id: sessionId,
      userId: user.id,
      phoneNumber: normalizedPhone,
      refreshTokenHash: hashSync(refreshToken, 10),
      tokenFamilyId,
      tokenGeneration: 0,
      deviceId: dto.deviceId,
      userAgent,
      ipAddress,
      expiresAt: sessionExpiry,
      isActive: true,
    });

    await this.userSessionRepository.save(session);

    this.logger.log(`User ${user.id} authenticated via phone OTP`);

    return {
      success: true,
      accessToken,
      user: {
        id: user.id.toString(),
        phoneNumber: normalizedPhone,
        phoneVerified: true,
        tier: user.tier || 'free',
        isNewUser,
      },
      session: {
        id: sessionId,
        expiresAt: sessionExpiry.toISOString(),
      },
    };
  }

  /**
   * Resend OTP with rate limiting
   */
  async resendOTP(
    phoneNumber: string,
    purpose: OTPPurpose,
    ipAddress: string,
    userAgent: string,
  ): Promise<RequestOTPResponseDto> {
    return this.sendOTP({ phoneNumber, purpose }, ipAddress, userAgent);
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(refreshToken: string): Promise<{ accessToken: string }> {
    try {
      const payload = this.jwtService.verify(refreshToken);

      if (payload.type !== 'refresh') {
        throw new UnauthorizedException('Invalid token type');
      }

      // Find the session
      const session = await this.userSessionRepository.findOne({
        where: {
          id: payload.sessionId,
          isActive: true,
        },
      });

      if (!session) {
        throw new UnauthorizedException('Session not found or revoked');
      }

      // Check if session is expired
      if (new Date() > session.expiresAt) {
        await this.revokeSession(session.id, 'Session expired');
        throw new UnauthorizedException('Session has expired');
      }

      // Verify token family and generation (detect replay attacks)
      if (
        session.tokenFamilyId !== payload.familyId ||
        session.tokenGeneration !== payload.generation
      ) {
        // Potential replay attack - revoke all sessions in this family
        await this.revokeTokenFamily(payload.familyId, 'Replay attack detected');
        throw new UnauthorizedException('Invalid refresh token');
      }

      // Get user
      const user = await this.usersService.findById(payload.sub);
      if (!user) {
        throw new UnauthorizedException('User not found');
      }

      // Generate new access token
      const accessToken = this.jwtService.sign(
        {
          sub: user.id,
          type: 'access',
          phoneNumber: session.phoneNumber,
          phoneVerified: user.verified,
          tier: user.tier || 'free',
          role: user.role,
          sessionId: session.id,
        },
        { expiresIn: this.accessTokenExpiry },
      );

      // Update session last activity
      await this.userSessionRepository.update(session.id, {
        lastActiveAt: new Date(),
      });

      return { accessToken };
    } catch (error: any) {
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Refresh token has expired');
      }
      throw error;
    }
  }

  /**
   * Revoke a specific session
   */
  async revokeSession(sessionId: string, reason?: string): Promise<void> {
    await this.userSessionRepository.update(sessionId, {
      isActive: false,
      revokedAt: new Date(),
      revokedReason: reason || 'Manual revocation',
    });
  }

  /**
   * Revoke all sessions in a token family
   */
  private async revokeTokenFamily(familyId: string, reason: string): Promise<void> {
    await this.userSessionRepository.update(
      { tokenFamilyId: familyId },
      {
        isActive: false,
        revokedAt: new Date(),
        revokedReason: reason,
      },
    );
  }

  /**
   * Get active sessions for a user
   */
  async getUserSessions(userId: number): Promise<UserSession[]> {
    return this.userSessionRepository.find({
      where: {
        userId,
        isActive: true,
      },
      order: {
        lastActiveAt: 'DESC',
      },
    });
  }

  /**
   * Revoke all sessions for a user
   */
  async revokeAllUserSessions(userId: number, reason?: string): Promise<void> {
    await this.userSessionRepository.update(
      { userId, isActive: true },
      {
        isActive: false,
        revokedAt: new Date(),
        revokedReason: reason || 'Logout from all devices',
      },
    );
  }

  private getOTPCacheKey(phoneNumber: string, purpose: OTPPurpose): string {
    return `otp:${purpose}:${phoneNumber}`;
  }

  private getRateLimitKey(type: string, identifier: string, window: string): string {
    return `ratelimit:otp:${type}:${window}:${identifier}`;
  }

  private async checkRateLimits(phoneNumber: string, ipAddress: string): Promise<void> {
    // Check if rate limiting is disabled
    // DISABLE_RATE_LIMITS defaults to true if NODE_ENV is 'development', false otherwise
    const disableRateLimits = process.env.DISABLE_RATE_LIMITS;
    if (disableRateLimits !== undefined && disableRateLimits === 'true') {
      return;
    }
    if (process.env.NODE_ENV === 'development') {
      return;
    }

    // Check phone-based rate limits
    const phoneMinute = await this.getRateLimitInfo(
      this.getRateLimitKey('phone', phoneNumber, '1m'),
    );
    if (phoneMinute && phoneMinute.count >= 1) {
      // Calculate retryAfter: time until reset in seconds
      const resetTime = new Date(phoneMinute.resetAt).getTime();
      const now = Date.now();
      const diffSeconds = Math.ceil((resetTime - now) / 1000);
      
      // Ensure retryAfter is always positive and reasonable (max 1 hour)
      // If resetAt is in the past or calculation is invalid, use a default value
      let retryAfter: number;
      if (diffSeconds > 0 && diffSeconds <= 3600) {
        retryAfter = diffSeconds;
      } else {
        // If invalid or negative, use a reasonable default (60 seconds)
        retryAfter = 60;
      }
      
      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: `OTP request limit exceeded. Please try again in ${retryAfter} seconds.`,
          retryAfter: retryAfter,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    const phoneHour = await this.getRateLimitInfo(
      this.getRateLimitKey('phone', phoneNumber, '1h'),
    );
    if (phoneHour && phoneHour.count >= 5) {
      // Calculate retryAfter for hourly limit
      const resetTime = new Date(phoneHour.resetAt).getTime();
      const now = Date.now();
      const diffSeconds = Math.ceil((resetTime - now) / 1000);
      
      let retryAfter: number;
      if (diffSeconds > 0 && diffSeconds <= 3600) {
        retryAfter = diffSeconds;
      } else {
        retryAfter = 3600; // Default to 1 hour
      }
      
      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: 'Hourly OTP limit exceeded. Please try again later.',
          retryAfter: retryAfter,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    const phoneDay = await this.getRateLimitInfo(
      this.getRateLimitKey('phone', phoneNumber, '24h'),
    );
    if (phoneDay && phoneDay.count >= 10) {
      // Calculate retryAfter for daily limit
      const resetTime = new Date(phoneDay.resetAt).getTime();
      const now = Date.now();
      const diffSeconds = Math.ceil((resetTime - now) / 1000);
      
      let retryAfter: number;
      if (diffSeconds > 0 && diffSeconds <= 3600) {
        retryAfter = diffSeconds;
      } else {
        retryAfter = 3600; // Default to 1 hour (max displayable)
      }
      
      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: 'Daily OTP limit exceeded. Please try again tomorrow.',
          retryAfter: retryAfter,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    // Check IP-based rate limits
    const ipMinute = await this.getRateLimitInfo(
      this.getRateLimitKey('ip', ipAddress, '1m'),
    );
    if (ipMinute && ipMinute.count >= 10) {
      // Calculate retryAfter for IP limit
      const resetTime = new Date(ipMinute.resetAt).getTime();
      const now = Date.now();
      const diffSeconds = Math.ceil((resetTime - now) / 1000);
      
      let retryAfter: number;
      if (diffSeconds > 0 && diffSeconds <= 3600) {
        retryAfter = diffSeconds;
      } else {
        retryAfter = 60; // Default to 60 seconds
      }
      
      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: 'Too many requests from this IP. Please try again later.',
          retryAfter: retryAfter,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }
  }

  private async getRateLimitInfo(key: string): Promise<RateLimitInfo | null> {
    const data = await this.cacheService.getKey(key);
    if (data) {
      return JSON.parse(data as string);
    }
    return null;
  }

  private async updateRateLimits(phoneNumber: string, ipAddress: string): Promise<void> {
    // Update phone rate limits
    await this.incrementRateLimit(
      this.getRateLimitKey('phone', phoneNumber, '1m'),
      60,
    );
    await this.incrementRateLimit(
      this.getRateLimitKey('phone', phoneNumber, '1h'),
      3600,
    );
    await this.incrementRateLimit(
      this.getRateLimitKey('phone', phoneNumber, '24h'),
      86400,
    );

    // Update IP rate limits
    await this.incrementRateLimit(this.getRateLimitKey('ip', ipAddress, '1m'), 60);
    await this.incrementRateLimit(this.getRateLimitKey('ip', ipAddress, '1h'), 3600);
  }

  private async incrementRateLimit(key: string, ttlSeconds: number): Promise<void> {
    const existing = await this.getRateLimitInfo(key);
    const now = new Date();
    const resetAt = new Date(now.getTime() + ttlSeconds * 1000);

    const info: RateLimitInfo = existing
      ? { count: existing.count + 1, resetAt: existing.resetAt }
      : { count: 1, resetAt: resetAt.toISOString() };

    await this.cacheService.setKey(key, JSON.stringify(info), ttlSeconds);
  }

  private async invalidateOTP(phoneNumber: string, purpose: OTPPurpose): Promise<void> {
    const cacheKey = this.getOTPCacheKey(phoneNumber, purpose);
    await this.cacheService.deleteKey(cacheKey);
  }

  private async logOTPAudit(
    phoneNumber: string,
    purpose: EntityOTPPurpose,
    action: OTPAction,
    ipAddress: string,
    userAgent: string,
    attemptCount: number,
    success: boolean,
    failureReason?: string,
  ): Promise<void> {
    try {
      const audit = this.otpAuditRepository.create({
        phoneNumber,
        purpose,
        action,
        ipAddress,
        userAgent,
        attemptCount,
        success,
        failureReason,
      });
      await this.otpAuditRepository.save(audit);
    } catch (error) {
      // Don't let audit failures break the main flow
      this.logger.error(`Failed to log OTP audit: ${error}`);
    }
  }
}
