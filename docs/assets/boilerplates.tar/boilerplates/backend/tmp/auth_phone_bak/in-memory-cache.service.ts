import { Injectable } from '@nestjs/common';

interface CacheEntry {
  value: string;
  expiresAt: number;
}

@Injectable()
export class InMemoryCacheService {
  private readonly store = new Map<string, CacheEntry>();

  async setKey(key: string, value: string, ttlSeconds?: number): Promise<void> {
    const expiresAt = ttlSeconds
      ? Date.now() + ttlSeconds * 1000
      : Number.MAX_SAFE_INTEGER;
    this.store.set(key, { value, expiresAt });
  }

  async getKey(key: string): Promise<string | null> {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.value;
  }

  async deleteKey(key: string): Promise<void> {
    this.store.delete(key);
  }
}
