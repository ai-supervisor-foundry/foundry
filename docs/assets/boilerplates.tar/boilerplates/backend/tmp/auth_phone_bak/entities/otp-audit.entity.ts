import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';

export enum OTPAction {
  SENT = 'sent',
  VERIFIED = 'verified',
  EXPIRED = 'expired',
  BLOCKED = 'blocked',
  FAILED = 'failed',
}

export enum OTPPurpose {
  LOGIN = 'login',
  REGISTRATION = 'registration',
  PASSWORD_RESET = 'password_reset',
  PHONE_VERIFICATION = 'phone_verification',
}

@Entity('otp_audit_log')
@Index('idx_otp_audit_phone', ['phoneNumber'])
@Index('idx_otp_audit_created', ['createdAt'])
@Index('idx_otp_audit_action', ['action'])
export class OTPAudit {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 20 })
  phoneNumber: string;

  @Column({
    type: 'enum',
    enum: OTPPurpose,
  })
  purpose: OTPPurpose;

  @Column({
    type: 'enum',
    enum: OTPAction,
  })
  action: OTPAction;

  @Column({ type: 'inet', nullable: true })
  ipAddress: string;

  @Column({ type: 'text', nullable: true })
  userAgent: string;

  @Column({ type: 'smallint', default: 0 })
  attemptCount: number;

  @Column({ type: 'boolean', default: false })
  success: boolean;

  @Column({ type: 'varchar', length: 100, nullable: true })
  failureReason: string;

  @CreateDateColumn()
  createdAt: Date;
}
