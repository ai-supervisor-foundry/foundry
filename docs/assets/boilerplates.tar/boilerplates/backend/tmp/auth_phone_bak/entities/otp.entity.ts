import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';
import { OTPPurpose } from './otp-audit.entity';

@Entity('otps')
@Index('idx_otp_phone_purpose', ['phoneNumber', 'purpose'])
@Index('idx_otp_expires', ['expiresAt'])
@Index('idx_otp_phone_expires', ['phoneNumber', 'expiresAt'])
export class OTP {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 20 })
  phoneNumber: string;

  @Column({ type: 'varchar', length: 255 })
  otpHash: string;

  @Column({
    type: 'enum',
    enum: OTPPurpose,
  })
  purpose: OTPPurpose;

  @Column({ type: 'smallint', default: 0 })
  attemptCount: number;

  @Column({ type: 'smallint', default: 3 })
  maxAttempts: number;

  @Column({ 
    type: 'timestamp',
    name: 'expires_at',
    nullable: false,
  })
  expiresAt: Date;

  @Column({ type: 'inet', nullable: true })
  ipAddress: string;

  @Column({ type: 'text', nullable: true })
  userAgent: string;

  @Column({ type: 'boolean', default: false })
  isUsed: boolean;

  @CreateDateColumn()
  createdAt: Date;
}
