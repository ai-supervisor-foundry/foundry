import {
  PipeTransform,
  Injectable,
  ArgumentMetadata,
  BadRequestException,
} from '@nestjs/common';

// Supported country configurations
const SUPPORTED_COUNTRIES: Record<
  string,
  { code: string; mobilePrefixes: string[] }
> = {
  PK: { code: '92', mobilePrefixes: ['30', '31', '32', '33', '34', '35', '36', '37', '38', '39'] },
  AE: { code: '971', mobilePrefixes: ['50', '52', '54', '55', '56', '58'] },
  SA: {
    code: '966',
    mobilePrefixes: ['50', '53', '54', '55', '56', '57', '58', '59'],
  },
  QA: {
    code: '974',
    mobilePrefixes: ['30', '31', '32', '33', '34', '55', '66', '77'],
  },
  KW: {
    code: '965',
    mobilePrefixes: [
      '50',
      '51',
      '52',
      '54',
      '55',
      '56',
      '57',
      '58',
      '59',
      '60',
      '61',
      '65',
      '66',
      '67',
      '69',
    ],
  },
  BH: {
    code: '973',
    mobilePrefixes: [
      '30',
      '31',
      '32',
      '33',
      '34',
      '35',
      '36',
      '37',
      '38',
      '39',
      '66',
      '67',
      '68',
      '69',
    ],
  },
  OM: {
    code: '968',
    mobilePrefixes: ['90', '91', '92', '93', '94', '95', '96', '97', '98', '99'],
  },
};

export interface PhoneValidationResult {
  isValid: boolean;
  normalizedNumber?: string;
  countryCode?: string;
  countryCallingCode?: string;
  nationalNumber?: string;
  numberType?: 'mobile' | 'landline' | 'unknown';
  error?: {
    code:
      | 'INVALID_FORMAT'
      | 'INVALID_COUNTRY'
      | 'NOT_MOBILE'
      | 'TOO_SHORT'
      | 'TOO_LONG';
    message: string;
  };
}

export interface PhoneValidationOptions {
  defaultCountry?: string;
  requireMobile?: boolean;
  throwOnInvalid?: boolean;
}

@Injectable()
export class PhoneValidationPipe implements PipeTransform {
  private readonly defaultCountry: string;
  private readonly requireMobile: boolean;
  private readonly throwOnInvalid: boolean;

  constructor(options: PhoneValidationOptions = {}) {
    this.defaultCountry = options.defaultCountry || 'PK';
    this.requireMobile = options.requireMobile !== false; // Default true
    this.throwOnInvalid = options.throwOnInvalid !== false; // Default true
  }

  transform(value: any, metadata: ArgumentMetadata): string | PhoneValidationResult {
    // Handle object with phoneNumber property
    const phoneNumber =
      typeof value === 'string' ? value : value?.phoneNumber;

    if (!phoneNumber) {
      if (this.throwOnInvalid) {
        throw new BadRequestException('Phone number is required');
      }
      return {
        isValid: false,
        error: {
          code: 'INVALID_FORMAT',
          message: 'Phone number is required',
        },
      };
    }

    const result = this.validatePhoneNumber(phoneNumber);

    if (!result.isValid && this.throwOnInvalid) {
      throw new BadRequestException(result.error?.message || 'Invalid phone number');
    }

    // If value was an object, return the object with normalized phone number
    if (typeof value === 'object' && result.isValid) {
      return {
        ...value,
        phoneNumber: result.normalizedNumber,
      };
    }

    // If throwOnInvalid is true, return the normalized number
    if (this.throwOnInvalid && result.isValid) {
      return result.normalizedNumber!;
    }

    return result;
  }

  private validatePhoneNumber(phoneNumber: string): PhoneValidationResult {
    // Remove all whitespace and special characters except +
    let cleaned = phoneNumber.replace(/[\s\-\(\)]/g, '');

    // Handle different input formats
    if (cleaned.startsWith('00')) {
      cleaned = '+' + cleaned.substring(2);
    } else if (!cleaned.startsWith('+')) {
      // Check if it starts with country code without +
      const countryConfig = SUPPORTED_COUNTRIES[this.defaultCountry];
      if (countryConfig) {
        if (cleaned.startsWith(countryConfig.code)) {
          cleaned = '+' + cleaned;
        } else if (cleaned.startsWith('0')) {
          // Local format with leading 0
          cleaned = '+' + countryConfig.code + cleaned.substring(1);
        } else {
          cleaned = '+' + countryConfig.code + cleaned;
        }
      }
    }

    // Extract country code and national number
    let countryCode: string | undefined;
    let countryCallingCode: string | undefined;
    let nationalNumber: string | undefined;

    for (const [code, config] of Object.entries(SUPPORTED_COUNTRIES)) {
      if (cleaned.startsWith('+' + config.code)) {
        countryCode = code;
        countryCallingCode = config.code;
        nationalNumber = cleaned.substring(1 + config.code.length);
        break;
      }
    }

    if (!countryCode || !nationalNumber) {
      return {
        isValid: false,
        error: {
          code: 'INVALID_COUNTRY',
          message: 'Phone number country is not supported',
        },
      };
    }

    // Validate national number length (7-10 digits for supported countries)
    if (nationalNumber.length < 7) {
      return {
        isValid: false,
        error: {
          code: 'TOO_SHORT',
          message: `Phone number has invalid length: ${nationalNumber.length} digits`,
        },
      };
    }

    if (nationalNumber.length > 10) {
      return {
        isValid: false,
        error: {
          code: 'TOO_LONG',
          message: `Phone number has invalid length: ${nationalNumber.length} digits`,
        },
      };
    }

    // Check if it's a mobile number (if required)
    const countryConfig = SUPPORTED_COUNTRIES[countryCode];
    const prefix = nationalNumber.substring(0, 2);
    const isMobile = countryConfig.mobilePrefixes.includes(prefix);

    if (this.requireMobile && !isMobile) {
      return {
        isValid: false,
        error: {
          code: 'NOT_MOBILE',
          message: 'Only mobile phone numbers are accepted',
        },
      };
    }

    return {
      isValid: true,
      normalizedNumber: cleaned,
      countryCode,
      countryCallingCode,
      nationalNumber,
      numberType: isMobile ? 'mobile' : 'landline',
    };
  }
}

/**
 * Standalone phone validation function for use outside pipes
 */
export function validatePhoneNumber(
  phoneNumber: string,
  defaultCountry: string = 'PK',
): PhoneValidationResult {
  const pipe = new PhoneValidationPipe({
    defaultCountry,
    requireMobile: true,
    throwOnInvalid: false,
  });
  return pipe.transform(phoneNumber, { type: 'body' }) as PhoneValidationResult;
}
