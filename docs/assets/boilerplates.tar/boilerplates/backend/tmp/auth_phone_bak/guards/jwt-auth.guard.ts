import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import type { Request } from 'express';
import { EnvProps } from '../../../../env';

export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () =>
  (target: any, propertyKey?: string, descriptor?: PropertyDescriptor) => {
    if (descriptor) {
      Reflect.defineMetadata(IS_PUBLIC_KEY, true, descriptor.value);
    } else {
      Reflect.defineMetadata(IS_PUBLIC_KEY, true, target);
    }
  };

// Phone auth token payload (from phone authentication)
export interface PhoneJwtPayload {
  sub: number;
  type: 'access' | 'refresh';
  phoneNumber: string;
  phoneVerified: boolean;
  tier: string;
  role: string;
  sessionId: string;
  iat: number;
  exp: number;
}

// Email/password auth token payload (from email authentication)
export interface EmailJwtPayload {
  id: number;
  email: string;
  name: string;
  role: string;
  iat?: number;
  exp?: number;
}

// Unified payload type
export type JwtPayload = PhoneJwtPayload | EmailJwtPayload;

// Normalized user payload attached to request
export interface NormalizedUserPayload {
  id: number;
  email?: string;
  name?: string;
  role: string;
  phoneNumber?: string;
  phoneVerified?: boolean;
  tier?: string;
  sessionId?: string;
  type?: 'access' | 'refresh';
}

export interface AuthenticatedRequest extends Request {
  user: NormalizedUserPayload;
  user_id: number;
  token: string;
}

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService<EnvProps, true>,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    // Check if the route is marked as public
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (isPublic) {
      return true;
    }

    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const token = this.extractTokenFromHeader(request);

    if (!token) {
      throw new UnauthorizedException('Missing authentication token');
    }

    try {
      const payload = await this.jwtService.verifyAsync<JwtPayload>(token, {
        secret: this.configService.get('JWT_SECRET'),
      });

      // Normalize payload to handle both phone auth and email/password auth tokens
      const normalizedPayload = this.normalizePayload(payload);

      // Validate token type for phone auth tokens (email/password tokens don't have type)
      // Only validate type if it exists in the payload (phone auth tokens have type, email/password don't)
      if ('type' in payload && payload.type && payload.type !== 'access') {
        throw new UnauthorizedException('Invalid token type');
      }

      // Attach normalized user info and user_id to request context
      request.user = normalizedPayload;
      request.user_id = normalizedPayload.id;
      request.token = token;
    } catch (error: any) {
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token has expired');
      }
      if (error.name === 'JsonWebTokenError') {
        throw new UnauthorizedException('Invalid token');
      }
      throw new UnauthorizedException(error.message || 'Authentication failed');
    }

    return true;
  }

  private extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type?.toLowerCase() === 'bearer' ? token : undefined;
  }

  /**
   * Normalize JWT payload to handle both phone auth and email/password auth tokens
   */
  private normalizePayload(payload: JwtPayload): NormalizedUserPayload {
    // Phone auth token format
    if ('type' in payload && 'sub' in payload) {
      const phonePayload = payload as PhoneJwtPayload;
      return {
        id: phonePayload.sub,
        role: phonePayload.role,
        phoneNumber: phonePayload.phoneNumber,
        phoneVerified: phonePayload.phoneVerified,
        tier: phonePayload.tier,
        sessionId: phonePayload.sessionId,
        type: phonePayload.type,
      };
    }

    // Email/password auth token format
    if ('id' in payload && 'email' in payload) {
      const emailPayload = payload as EmailJwtPayload;
      return {
        id: emailPayload.id,
        email: emailPayload.email,
        name: emailPayload.name,
        role: emailPayload.role,
      };
    }

    // Fallback: try to extract id from either format
    const payloadAny = payload as any;
    const id = ('sub' in payloadAny ? payloadAny.sub : ('id' in payloadAny ? payloadAny.id : null));
    if (!id) {
      throw new UnauthorizedException('Invalid token payload structure');
    }

    return {
      id,
      role: payloadAny.role || 'user',
    };
  }
}
