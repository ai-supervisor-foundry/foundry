# Controllers Directory

This directory is part of the basic project structure. In this NestJS project, controllers are organized by feature in the `src/modules/` directory.

## NestJS Structure

Controllers are located in their respective modules:
- `src/modules/auth/auth.controller.ts`
- `src/modules/users/users.controller.ts`
- `src/modules/listings/listings.controller.ts`
- `src/modules/storage/storage.controller.ts`
- And other feature modules...

Each module follows NestJS conventions with its own controller, service, and related files.
